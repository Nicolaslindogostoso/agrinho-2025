// ===========================================
// Variáveis Globais (início do seu sketch.js)
// ===========================================
let canteiros = []; // Array para armazenar informações sobre cada canteiro
let aguaDisponivel = 100; // Quantidade inicial de água (em porcentagem)
let maxAgua = 100; // Água máxima que pode ser armazenada
let pontos = 0; // Pontuação do jogador
let recordeMundial = 0; // Armazenará o recorde mundial (local)

// Constantes para o jogo
const NUM_CANTEIROS = 5; // Quantidade de canteiros na horta
const TAM_CANTEIRO_LARGURA = 100;
const TAM_CANTEIRO_ALTURA = 60;
const ESPACAMENTO_CANTEIRO = 20;

// Estados da planta (para cada canteiro)
const ESTADO_VAZIO = 0;
const ESTADO_SEMENTE = 1;
const ESTADO_CRESCENDO = 2;
const ESTADO_PRONTO_COLHER = 3;

// ===========================================
// Variáveis para o Menu e Estados do Jogo
// ===========================================
const TELA_MENU = 0;
const TELA_JOGO = 1;
const TELA_FIM_JOGO = 2; // Novo estado para quando o jogo acaba (ainda não implementado)
let estadoAtual = TELA_MENU; // Começa no menu

// ===========================================
// Função setup()
// ===========================================
function setup() {
  createCanvas(800, 500);

  // Tenta carregar o recorde mundial salvo no navegador
  let recordeSalvo = localStorage.getItem('recordeAgrinhoHorta');
  if (recordeSalvo !== null) {
    recordeMundial = parseInt(recordeSalvo);
  }

  // A inicialização dos canteiros agora será feita quando o jogo começar de fato
  // (no resetGame() ou quando sair do menu)
  resetGame(); // Chama para iniciar os canteiros (inicializa para a primeira vez)
}

// ===========================================
// Função draw()
// ===========================================
function draw() {
  background(135, 206, 235); // Céu azul

  if (estadoAtual === TELA_MENU) {
    desenharMenu();
  } else if (estadoAtual === TELA_JOGO) {
    // ---- ADICIONE ESTA LINHA AQUI ----
    rectMode(CORNER); // Garante que retângulos são desenhados do canto superior esquerdo
    // ----------------------------------

    // Desenha o chão/terra
    fill(139, 69, 19); // Cor de terra
    rect(0, height - 100, width, 100);

    desenharHorta();
    desenharMedidorAgua();
    desenharPontuacao();
    desenharRecordeMundial(); // Desenha o recorde mundial
    atualizarPlantas();
  }
  // else if (estadoAtual === TELA_FIM_JOGO) { // Futuramente, tela de fim de jogo
  //   desenharFimDeJogo();
  // }
}

// ===========================================
// Novas Funções para o Menu e Game Over
// ===========================================

function desenharMenu() {
  background(173, 216, 230); // Um azul mais claro para o menu

  fill(0, 100, 0); // Verde escuro para o título
  textSize(50);
  textAlign(CENTER, CENTER);
  text("Horta Sustentável do Agrinho", width / 2, height / 3);

  fill(50, 50, 50);
  textSize(24);
  text("Seja o melhor agrônomo!", width / 2, height / 2.2);

  // Botão Iniciar Jogo
  fill(0, 150, 0); // Verde para o botão
  rectMode(CENTER); // Define o modo de retângulo para CENTRALIZADO para o botão
  rect(width / 2, height / 1.5, 200, 60, 10); // Botão arredondado

  fill(255); // Texto branco
  textSize(30);
  text("COMEÇAR", width / 2, height / 1.5);
  // Após desenhar o menu, o rectMode(CENTER) permanece ativo até a próxima chamada de draw()
  // Mas a correção no draw() da tela do jogo garante que ele volte ao normal.

  // Exibe o Recorde Mundial no menu
  fill(50, 50, 50);
  textSize(20);
  text("Recorde Atual: " + recordeMundial + " pontos", width / 2, height - 50);
}

// Função para reiniciar o estado do jogo
function resetGame() {
  canteiros = []; // Limpa os canteiros
  for (let i = 0; i < NUM_CANTEIROS; i++) {
    canteiros.push({
      x: 50 + i * (TAM_CANTEIRO_LARGURA + ESPACAMENTO_CANTEIRO),
      y: height - TAM_CANTEIRO_ALTURA - 50,
      estado: ESTADO_VAZIO,
      tempoCrescimento: 0,
      precisaRegar: false
    });
  }
  aguaDisponivel = 100;
  pontos = 0;
  // Não reseta o recorde mundial aqui!
}

// ===========================================
// Funções Existentes (apenas pequenas modificações)
// ===========================================

// Função para desenhar os canteiros e as plantas
function desenharHorta() {
  for (let i = 0; i < canteiros.length; i++) {
    let c = canteiros[i];

    // Desenha o canteiro
    fill(101, 67, 33); // Cor de terra mais escura para o canteiro
    rect(c.x, c.y, TAM_CANTEIRO_LARGURA, TAM_CANTEIRO_ALTURA, 5); // Com bordas arredondadas

    // Desenha a planta de acordo com o estado
    if (c.estado === ESTADO_SEMENTE) {
      fill(50, 205, 50); // Verde para a semente
      ellipse(c.x + TAM_CANTEIRO_LARGURA / 2, c.y + TAM_CANTEIRO_ALTURA / 2, 10, 10);
    } else if (c.estado === ESTADO_CRESCENDO) {
      fill(34, 139, 34); // Verde mais escuro para o broto
      rect(c.x + TAM_CANTEIRO_LARGURA / 2 - 5, c.y + TAM_CANTEIRO_ALTURA / 2 - 20, 10, 20);
      ellipse(c.x + TAM_CANTEIRO_LARGURA / 2, c.y + TAM_CANTEIRO_ALTURA / 2 - 20, 15, 25);
      if (c.precisaRegar) {
        fill(255, 0, 0); // Vermelho se precisar regar
        noStroke();
        triangle(c.x + TAM_CANTEIRO_LARGURA / 2, c.y - 10, c.x + TAM_CANTEIRO_LARGURA / 2 - 5, c.y - 20, c.x + TAM_CANTEIRO_LARGURA / 2 + 5, c.y - 20); // Triângulo de alerta
        stroke(0);
      }
    } else if (c.estado === ESTADO_PRONTO_COLHER) {
      fill(255, 140, 0); // Laranja para a cenoura
      ellipse(c.x + TAM_CANTEIRO_LARGURA / 2, c.y + TAM_CANTEIRO_ALTURA / 2 - 10, 30, 40);
      fill(0, 128, 0); // Verde para as folhas
      rect(c.x + TAM_CANTEIRO_LARGURA / 2 - 5, c.y + TAM_CANTEIRO_ALTURA / 2 - 40, 10, 20);
    }
  }
}

// Função para desenhar o medidor de água
function desenharMedidorAgua() {
  noFill();
  stroke(0);
  rect(width - 150, 30, 120, 30);

  let larguraAgua = map(aguaDisponivel, 0, maxAgua, 0, 118);
  fill(0, 0, 255, 150);
  rect(width - 149, 31, larguraAgua, 28);

  fill(0);
  textSize(16);
  text("Água: " + floor(aguaDisponivel) + "%", width - 140, 75);
}

// Função para desenhar a pontuação
function desenharPontuacao() {
  fill(0);
  textSize(24);
  textAlign(LEFT, TOP); // Alinha o texto à esquerda superior
  text("Pontos: " + pontos, 30, 40);
}

// Nova função para desenhar o Recorde Mundial
function desenharRecordeMundial() {
  fill(0);
  textSize(20);
  textAlign(LEFT, TOP);
  text("Recorde: " + recordeMundial, 30, 70); // Abaixo dos pontos
}

// Função para atualizar o estado das plantas
function atualizarPlantas() {
  for (let i = 0; i < canteiros.length; i++) {
    let c = canteiros[i];

    if (c.estado === ESTADO_CRESCENDO) {
      c.tempoCrescimento++;

      // A planta precisa de água de tempos em tempos
      if (c.tempoCrescimento % 90 === 0 && random(1) < 0.5) {
        c.precisaRegar = true;
      }

      if (!c.precisaRegar) {
        if (c.tempoCrescimento > 300) {
          c.estado = ESTADO_PRONTO_COLHER;
          c.tempoCrescimento = 0;
        }
      } else {
        // Se a planta precisa regar e não foi regada por muito tempo, pode murchar
        // Exemplo: se passar 10 segundos (300 frames) precisando regar, ela morre
        if (c.tempoCrescimento > 300 + 300) { // Tempo de crescimento + tempo extra para regar
          c.estado = ESTADO_VAZIO; // Morre e o canteiro fica vazio
          pontos = max(0, pontos - 5); // Perde alguns pontos por deixar a planta morrer
          // Poderia adicionar uma mensagem de "planta murchou!"
        }
      }
    }
  }

  // Simula o reabastecimento de água (ex: chuva)
  if (frameCount % 600 === 0) {
    aguaDisponivel = min(aguaDisponivel + 10, maxAgua);
  }

  // Fim do jogo? (Exemplo: se a água acabar e não tiver como plantar/regar)
  // Ou se todas as plantas murcharem e o jogador não tiver pontos.
  // Isso será uma implementação futura, talvez para ir para TELA_FIM_JOGO
}

// ===========================================
// Função mousePressed()
// ===========================================
function mousePressed() {
  if (estadoAtual === TELA_MENU) {
    // Verifica se o clique foi no botão COMEÇAR
    // As coordenadas aqui ainda esperam rectMode(CENTER) porque a função desenharMenu() o definiu
    if (mouseX > width / 2 - 100 && mouseX < width / 2 + 100 &&
        mouseY > height / 1.5 - 30 && mouseY < height / 1.5 + 30) {
      estadoAtual = TELA_JOGO; // Mudar para a tela do jogo
      resetGame(); // Reseta o jogo para um novo começo
    }
  } else if (estadoAtual === TELA_JOGO) {
    // Lógica de clique no jogo (a mesma de antes)
    for (let i = 0; i < canteiros.length; i++) {
      let c = canteiros[i];

      if (mouseX > c.x && mouseX < c.x + TAM_CANTEIRO_LARGURA &&
          mouseY > c.y && mouseY < c.y + TAM_CANTEIRO_ALTURA) {

        if (c.estado === ESTADO_VAZIO && aguaDisponivel >= 5) { // Precisa de água para plantar
          c.estado = ESTADO_SEMENTE;
          aguaDisponivel -= 5;
          setTimeout(() => {
              c.estado = ESTADO_CRESCENDO;
          }, 500);
          return;
        } else if (c.estado === ESTADO_CRESCENDO && c.precisaRegar && aguaDisponivel >= 10) { // Precisa de água para regar
          c.precisaRegar = false;
          aguaDisponivel -= 10;
          return;
        } else if (c.estado === ESTADO_PRONTO_COLHER) {
          c.estado = ESTADO_VAZIO;
          pontos += 10;
          // Verifica se o novo ponto é um recorde
          if (pontos > recordeMundial) {
            recordeMundial = pontos;
            localStorage.setItem('recordeAgrinhoHorta', recordeMundial); // Salva o recorde
          }
          return;
        }
      }
    }
  }
}